# :desktop_computer: Meu portal de filmes

Site desenvolvido na matéria de Desenvolvimento de Interfaces Web no primeiro período do curso de Ciência da Computação.

Nesse arquivo contém os arquivos utilizados no desenvolvimento do site.

Para acessar o site em um ambiente da internet, clique [aqui](https://meu-portal-de-filmes.gabrielribeiro99.repl.co/) ou <https://meu-portal-de-filmes.gabrielribeiro99.repl.co/>.

Desenvolvido por Gabriel Ribeiro Souza Silva.